﻿int numero;
int resultado;
int letraindex;
Console.WriteLine("Ingrese un numero entero");
numero = int.Parse(Console.ReadLine());
resultado = numero % 1000;
letraindex = numero / 1000;
if (resultado == 0) ;
{

}